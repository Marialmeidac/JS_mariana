function obterMensagens() {

    var mensagens = [];

    $.ajax({
        url: 'https://app-p2-aab7c7fdddb8.herokuapp.com/mensagens',
        method: 'GET',
        dataType: 'json',
        async: false,
        success: function (response) {
            mensagens = response;
        },
        error: function (error) {
            console.error('Erro ao obter mensagens:', error);
        }
    });

    return mensagens;
}

function inserirMensagem(mensagem) {

    $.ajax({
        url: 'https://app-p2-aab7c7fdddb8.herokuapp.com/mensagens/inserir',
        method: 'POST',
        dataType: 'json',
        contentType: 'application/json',
        data: JSON.stringify(mensagem),
        success: function (response) {
            alert('Mensagem enviada com sucesso!');
        },
        error: function (error) {
            alert('Erro ao enviar mensagem: ' + error.responseText);
        }
    });
}

var inserir = $.ajax({

    url: 'https://app-p2-aab7c7fdddb8.herokuapp.com/mensagens',
    method: 'POST',
    data: JSON.stringify(mensagem),
    dataType: 'json',
    async: false,
    contentType: 'application/json',
});


function validarUsuario(objLoginSenha) {

    var retorno = false;

    var validacao = $.ajax({
        url: 'https://app-p2-aab7c7fdddb8.herokuapp.com/usuarios/validar',
        method: 'POST',
        dataType: 'json',
        async: false,
        contentType: 'application/json',
        data: JSON.stringify(objLoginSenha),
        success: function (response) {
            retorno = response.valido;
        },
        error: function (error) {
            console.error('Erro ao validar usuário:', error);
        }
    });

    return retorno;
}